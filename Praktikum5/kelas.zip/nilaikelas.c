// Nama : Fabian Savero Diaz Pranoto
// NIM : 13519140
// Tanggal : 24 September 2020
// Topik : Matriks
// Deskripsi : Nilai Kelas

#include <stdio.h>
#include "boolean.h"
#include "matriks.h"

void TulisNilaiX(MATRIKS M, int j, int x);
void TulisStatistikMhs(MATRIKS M, int i);
void TulisStatistikMK(MATRIKS M, int j);

int main() {
    MATRIKS MNilai;
    int n,m;
    scanf("%d", &n);
    scanf("%d", &m);
    BacaMATRIKS(&MNilai, n, m);
    printf("STATISTIK PER MAHASISWA\n");
    for (int i = 0; i<=GetLastIdxBrs(MNilai); i++) {
        TulisStatistikMhs(MNilai,i);
        printf("\n");
    }
    printf("STATISTIK PER MATA KULIAH\n");
    for (int j = 0; j<=GetLastIdxKol(MNilai); j++) {
        TulisStatistikMK(MNilai,j);
        printf("\n");
    }
    return 0;
}

void TulisNilaiX(MATRIKS M, int j, int x)
{
    int count = CountXKol(M,j,x);
    printf("[");
    for (int i = 0; i<=GetLastIdxBrs(M); i++) {
        if ((Elmt(M,i,j)==x) && (count > 0)) {
            if (count-- == 1) {
                printf("%d",i);
            } else {
                printf("%d,",i);
            }
        }
    }
    printf("]");
}

void TulisStatistikMhs(MATRIKS M, int i)
{
    int max,min;
    float rata2 = RataBrs(M,i);
    MaxMinBrs(M,i,&max,&min);
    printf("[%d] %.2f %d %d", i, rata2, max, min);
}

void TulisStatistikMK(MATRIKS M, int j)
{
    int max,min;
    MaxMinKol(M, j, &max, &min);
    int cmax = CountXKol(M,j,max);
    int cmin = CountXKol(M,j,min);
    float rata2 = RataKol(M,j);
    printf("[%d] %.2f [%d %d ", j, rata2, max, cmax);
    TulisNilaiX(M,j,max);
    printf("] ");
    printf("[%d %d ", min, cmin);
    TulisNilaiX(M,j,min);
    printf("]");
}